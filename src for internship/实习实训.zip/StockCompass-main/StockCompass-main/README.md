# StockCompass







## Web前端项目

前端项目位于frontend文件夹中。

使用HBuilder X进行项目开发。

## Web后端项目

后端项目位于backend文件夹中。

使用IDEA进行项目开发。

## 大数据项目

在scala文件夹中存放.scala代码文件。