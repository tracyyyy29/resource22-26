package com;

//import org.service.SpringApplication;

public class App {
    public static void main(String [] args){
        org.cat.run(App.class);
    }
}